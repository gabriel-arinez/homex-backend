"""Fachada determinística F03: una captura produce cero o una propuesta."""

from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal
from time import perf_counter

from homex_nlp.contracts import (
    Accessory,
    Dimension,
    ExtractionRequest,
    ExtractionResult,
    ItemProposal,
    Measurement,
    NegotiatedPrice,
    UnitPrice,
)
from homex_nlp.contracts.evidence import Candidate, Warning
from homex_nlp.contracts.result import EngineInfo
from homex_nlp.product_relations import resolve_product_references
from homex_nlp.rules import (
    NUMBER_WORDS,
    Match,
    _commercial_count_match,
    _commercial_count_pattern,
    find_accessories,
    find_accessory_quantity,
    find_ambiguous_price,
    find_measurements,
    find_price,
    find_products,
    find_quantity,
    find_thicknesses,
    is_explicitly_negated,
    is_price_alternative,
    is_price_correction,
    money,
    price_mentions,
)

_GENERIC_FURNITURE_DETAIL = re.compile(
    r"\b(?:de\s+(?:madera|metal|acero|melamina|aglomerado)|"
    r"caj[oó]n(?:es)?|gavetas?|casilleros?|puertas?|repisas?|divisiones?|estantes?|estructura|"
    r"patas|plegable|tapiz|malla|espuma)\b",
    re.I,
)


def _generic_description(text: str, product: Match) -> Match | None:
    """Admit local positive detail without guessing a structured attribute.

    Unmapped complements remain review evidence, not material or feature values.
    Pronouns and audio-test intent do not supply product description evidence.
    """
    match = re.match(
        r"\s+(?P<detail>(?:de|en|con)\s+(?!(?:eso|esto|algo|nada|ello|el|la|los|las)\b)"
        r"[a-záéíóúñ][\wáéíóúñ-]*(?:\s+[\wáéíóúñ-]+){0,7})(?=[,.;\n]|$)",
        text[product.end :],
        re.I,
    )
    if not match:
        return None
    start = product.end + match.start("detail")
    end = product.end + match.end("detail")
    detail = text[start:end]
    if is_explicitly_negated(text, start) or re.search(
        r"\b(?:prueb[ao]|probar|probando)\b.*\b(?:audio|voz|micr[oó]fono)\b"
        r"|\b(?:audio|micr[oó]fono)\b.*\b(?:prueb[ao]|probar|probando)\b",
        detail,
        re.I,
    ):
        return None
    return Match(start, end, detail, "DESCRIPCION_COMERCIAL")


class RulesEngine:
    rules_version = "prf04-rules-context-5"

    def extract(self, request: ExtractionRequest) -> ExtractionResult:
        started = perf_counter()
        text = request.text
        candidates: list[Candidate] = []
        warnings: list[Warning] = [
            Warning(
                code="RULES_ONLY_MODE",
                path="",
                severity="INFO",
                message="Extracción determinística sin modelo NER.",
            )
        ]
        counter = 0

        def candidate(match: Match, decision: str = "ACCEPTED", reason: str | None = None) -> str:
            nonlocal counter
            counter += 1
            identifier = f"c{counter}"
            value = match.value
            if isinstance(value, Decimal):
                value = str(value)
            elif isinstance(value, tuple):
                value = [str(part) if isinstance(part, Decimal) else part for part in value]
            candidates.append(
                Candidate(
                    candidate_id=identifier,
                    label=match.label,
                    start=match.start,
                    end=match.end,
                    text=match.text,
                    source="RULE",
                    normalized_value=value,
                    decision=decision,
                    reason=reason,
                )
            )
            return identifier

        if not text.strip():
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="NO_PRODUCT",
                        path="",
                        severity="REVIEW",
                        message="No se dictó un producto.",
                    )
                ],
                started,
            )
        from homex_nlp.furniture_knowledge import noncommercial_furniture_context

        if noncommercial_furniture_context(text):
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="NO_PRODUCT",
                        path="",
                        severity="REVIEW",
                        message="Noncommercial test or retrospective context; no affirmative product proposal.",
                    )
                ],
                started,
            )
        # La familia se determina por una mención comercial, nunca por
        # subcadenas («casillero») o una referencia espacial («del piso»).
        fuera = list(re.finditer(r"\b(?:sillas?|pisos?(?:\s+flotantes?)?)\b", text, re.I))
        conocidos = find_products(text)
        fuera_comercial = any(
            not is_explicitly_negated(text, m.start())
            and (
                not conocidos
                or m.start() < conocidos[0].start
                or re.search(
                    r"\b(?:y|adem[aá]s)\s+(?:quiero\s+|necesito\s+)?"
                    r"(?:\d+|" + "|".join(NUMBER_WORDS) + r")\s+$",
                    text[max(0, m.start() - 45) : m.start()],
                    re.I,
                )
            )
            for m in fuera
        )
        if fuera_comercial:
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="OUT_OF_VOICE_SCOPE",
                        path="",
                        severity="REVIEW",
                        message="El catálogo no pertenece al alcance de muebles a medida v1.",
                    )
                ],
                started,
            )
        products = [
            p
            for p in find_products(text)
            if not (
                p.text.lower().startswith(("cajonera", "casillero"))
                and re.search(
                    r"\bcon\s+(?:" + _commercial_count_pattern() + r"\s+)?$",
                    text[max(0, p.start - 200) : p.start],
                    re.I,
                )
            )
        ]
        # En una única línea comercial, «cada escritorio» reitera el mueble
        # inicial y «cajonera con N cajones» refiere a la cajonería integrada.
        # Rechazar otras conjunciones de productos sigue siendo obligatorio.
        if products:
            principal = products[0]
            integracion = bool(
                re.search(r"\bcajoner(?:[ií]a|a)\b[^.;]{0,45}\bintegrad[ao]s?\b", text, re.I)
            )
            filtrados = [principal]
            for producto in products[1:]:
                contexto = text[max(0, producto.start - 24) : producto.start]
                repeticion = producto.text.split()[0].casefold().rstrip(
                    "s"
                ) == principal.text.split()[0].casefold().rstrip("s") and re.search(
                    r"\bcada\s+$", contexto, re.I
                )
                componente = (
                    integracion
                    and producto.text.casefold().startswith("cajonera")
                    and re.search(
                        r"\bcajonera\s+con\s+(?:\d+|uno|una|dos|tres|cuatro)\s+cajones\b",
                        text[producto.start :],
                        re.I,
                    )
                )
                referencia_mesa = (
                    principal.text.casefold().startswith("mesa")
                    and producto.text.casefold().startswith("mesa")
                    and re.search(r"\buna\s+sola\s+$", contexto, re.I)
                    and (
                        (cantidad := find_quantity(text, main_product=principal)) is not None
                        and cantidad.value == 1
                        and cantidad.start > principal.end
                    )
                )
                if not (repeticion or componente or referencia_mesa):
                    filtrados.append(producto)
            products = filtrados

        # «Estantes» después de «con N ...» describe componentes,
        # no una segunda línea comercial; pedidos independientes siguen en revisión.
        menciones = products[:]
        products = [
            producto
            for producto in menciones
            if not (
                re.fullmatch(r"estantes?", producto.text, re.I)
                and any(
                    anterior.end <= producto.start
                    and re.fullmatch(
                        r"\s*,?\s*con\b[\w\s,]{0,100}\b(?:" + "|".join(NUMBER_WORDS) + r"|\d+)\s+",
                        text[anterior.end : producto.start],
                        re.I,
                    )
                    for anterior in menciones
                    if anterior != producto
                )
            )
        ]
        # «un escritorio, no mesa» no aclara si «mesa» es una corrección
        # sin pausa o una exclusión. Sin señal inequívoca, abstenerse.
        if any(
            re.search(
                r"[,;]\s*no\s+(?!(?:un|una|uno)\s+$)(?:" + _commercial_count_pattern() + r"\s+)?$",
                text[a.end : b.start],
                re.I,
            )
            for a, b in zip(products, products[1:])
        ):
            for ambiguous in products:
                candidate(ambiguous, "UNRESOLVED")
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="MULTIPLE_MAIN_PRODUCTS",
                        path="/item_proposal/name",
                        severity="REVIEW",
                        message="La negación del producto es ambigua; indique cuál desea cotizar.",
                    )
                ],
                started,
            )
        negated_products = [p for p in products if is_explicitly_negated(text, p.start)]
        for negated in negated_products:
            candidate(negated, "REJECTED", "Producto explícitamente negado")
        products = [p for p in products if p not in negated_products]
        if negated_products:
            warnings.append(
                Warning(
                    code="CONFLICTING_VALUES",
                    path="/item_proposal/name",
                    severity="REVIEW",
                    message="Se excluyó una referencia de producto negada; revise el nombre.",
                )
            )
        products, references = resolve_product_references(text, products, conocidos)
        for reference in references:
            candidate(
                reference, "REJECTED", "Referential/component mention, not an independent product"
            )
        if len(products) > 1:
            # Una segunda mención de «mesas» dentro del total negociado no
            # constituye otro producto si coincide con el tipo y la cantidad.
            principal = products[0].text.split()[0].casefold().rstrip("s")
            cantidad_principal = find_quantity(text, main_product=products[0])

            def referencia_del_total(producto: Match) -> bool:
                if cantidad_principal is None:
                    return False
                nombre = producto.text.split()[0].casefold().rstrip("s")
                if nombre != principal:
                    return False
                contexto = text[max(0, producto.start - 120) : producto.start]
                reiteracion = re.search(
                    r"\b(?:precio\s+total|total|monto(?:\s+total)?)"
                    r"\s+de\s+(?:las?|los?)\s+"
                    r"(\d+|" + "|".join(NUMBER_WORDS) + r")\s+$",
                    contexto,
                    re.I,
                )
                if reiteracion is None:
                    return False
                token = reiteracion.group(1).casefold()
                cantidad = NUMBER_WORDS.get(token)
                if cantidad is None and token.isdigit():
                    cantidad = int(token)
                return cantidad == cantidad_principal.value

            products = [
                producto
                for index, producto in enumerate(products)
                if index == 0 or not referencia_del_total(producto)
            ]

        # Corregir sólo con una señal positiva inequívoca ENTRE menciones.
        # «mesa, no un escritorio» niega el segundo producto, no rectifica al primero.
        # Una conjunción comercial («mesas y escritorios») sigue sin propuesta.
        def correccion_entre(anterior: Match, siguiente: Match) -> bool:
            fragmento = text[anterior.end : siguiente.start]
            return bool(
                re.search(
                    r"\b(?:no\s*,?\s*(?:mejor|quiero|necesito|sino)|"
                    r"perd[oó]n\s*,?\s*(?:mejor|quiero|sino)?|"
                    r"corrijo\s*,?\s*(?:es|mejor)|mejor|sino)\b",
                    fragmento,
                    re.I,
                )
            )

        if len(products) > 1 and correccion_entre(products[-2], products[-1]):
            for product in products[:-1]:
                candidate(product, "REJECTED", "Rectificado explícitamente en el dictado")
            products = [products[-1]]
            warnings.append(
                Warning(
                    code="CONFLICTING_VALUES",
                    path="/item_proposal/name",
                    severity="REVIEW",
                    message="Se aplicó la rectificación explícita; revisar.",
                )
            )
        elif len(products) > 1:
            for product in products:
                candidate(product, "UNRESOLVED")
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="MULTIPLE_MAIN_PRODUCTS",
                        path="",
                        severity="REVIEW",
                        message="Se detectaron varios productos principales.",
                    )
                ],
                started,
            )
        if not products:
            # Technical fragments retain source evidence but cannot establish
            # a commercial furniture identity or a fabricated proposal.
            for thickness in find_thicknesses(text):
                candidate(
                    thickness,
                    "UNRESOLVED",
                    "Technical gauge evidence; furniture identity and piece role require confirmation",
                )
                value, unit = thickness.value
                if unit is None and Decimal("0.5") <= value <= 60:
                    candidates[-1].normalized_value = {
                        "value": str(value),
                        "unit": "mm",
                        "value_mm": str(value),
                        "unit_inferred": True,
                    }
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="NO_PRODUCT",
                        path="",
                        severity="REVIEW",
                        message="No se detectó un producto principal.",
                    )
                ],
                started,
            )
        variants = re.search(
            r",\s*(una?)\s+de\b[^.;]*\by\s+(otra?)\b", text[products[0].end :], re.I
        )
        if variants:
            for group in (1, 2):
                start = products[0].end + variants.start(group)
                end = products[0].end + variants.end(group)
                candidate(Match(start, end, text[start:end], "PRODUCTO"), "UNRESOLVED")
            warnings.append(
                Warning(
                    code="MULTIPLE_MAIN_PRODUCTS",
                    path="/item_proposal/name",
                    severity="REVIEW",
                    message="Separate product descriptions require review.",
                )
            )
        generic_detail = (
            _generic_description(text, products[0])
            if re.fullmatch(r"muebles?", products[0].text, re.I)
            else None
        )
        if re.fullmatch(r"muebles?", products[0].text, re.I) and not (
            generic_detail
            or _GENERIC_FURNITURE_DETAIL.search(text[: products[0].start] + text[products[0].end :])
            or any(
                find_measurements(text, axis)
                for axis in ("ancho", "alto", "largo", "profundidad", "diametro")
            )
            or find_thicknesses(text)
            or find_price(text)[0]
        ):
            candidate(
                products[0],
                "UNRESOLVED",
                "Mueble genérico sin descripción comercial suficiente.",
            )
            return self._result(
                request,
                None,
                candidates,
                warnings
                + [
                    Warning(
                        code="NO_PRODUCT",
                        path="/item_proposal/name",
                        severity="REVIEW",
                        message="Describa el mueble antes de generar una propuesta.",
                    )
                ],
                started,
            )
        candidate(products[0])
        if generic_detail:
            candidate(
                generic_detail,
                "UNRESOLVED",
                "Descripción comercial conservada para revisión; no asigna atributos estructurados.",
            )
            warnings.append(
                Warning(
                    code="UNKNOWN_TERM",
                    path="/item_proposal/name",
                    severity="REVIEW",
                    message="Revise la descripción del mueble; los atributos no reconocidos no se completan.",
                )
            )
        quantity = find_quantity(text, main_product=products[0])
        if quantity:
            # Sólo correcciones contiguas y encadenadas del mismo campo.
            # Una cantidad seguida de un componente jamás sustituye muebles.
            offset = products[0].end
            original_quantity = quantity
            corrected = []
            pattern = re.compile(
                r"\s*[,;.]?\s*(?:no\s*,?\s*mejor|(?:corrijo|perd[oó]n)(?:\s*,?\s*mejor)?)\s*[,;]?\s*"
                r"(?P<number>cero|" + _commercial_count_pattern() + r")\b"
                r"(?:\s+(?:unidades?|muebles?))?",
                re.I,
            )
            while correction := pattern.match(text[offset:]):
                token = correction.group("number")
                start = offset + correction.start("number")
                parsed = _commercial_count_match(text, start, start + len(token))
                value = parsed.value if parsed else None
                corrected.append(Match(start, start + len(token), token, "CANTIDAD", value))
                offset += correction.end()
            if corrected:
                boundary = re.match(r"\s*(?:[,;.]|con\b|$)", text[offset:])
                if boundary and all(c.value and c.value > 0 for c in corrected):
                    for old in [original_quantity, *corrected[:-1]]:
                        candidate(old, "REJECTED", "Cantidad comercial rectificada")
                    quantity = corrected[-1]
                else:
                    for uncertain in [original_quantity, *corrected]:
                        candidate(
                            uncertain, "UNRESOLVED", "Rectificación comercial incompleta o ambigua"
                        )
                    quantity = None
        if quantity:
            candidate(quantity)
        if quantity is None:
            warnings.append(
                Warning(
                    code="NO_QUANTITY",
                    path="/item_proposal/quantity",
                    severity="REVIEW",
                    message="Indique cantidad de muebles.",
                )
            )
        dimensions: list[Dimension] = []
        for axis in ("ancho", "alto", "profundidad", "largo", "diametro"):
            for measurement in find_measurements(text, axis):
                evidence_id = candidate(measurement)
                value, raw_unit = measurement.value
                if raw_unit not in {"m", "mt", "mts", "metro", "metros", "cm", "mm"}:
                    warnings.append(
                        Warning(
                            code="MISSING_UNIT",
                            path="/item_proposal/dimensions",
                            severity="REVIEW",
                            message=f"La medida {measurement.text!r} no tiene unidad.",
                        )
                    )
                    unit = None
                    value_mm = None
                else:
                    unit = {"mt": "m", "mts": "m", "metro": "m", "metros": "m"}.get(
                        raw_unit, raw_unit
                    )
                    factor = {"m": Decimal(1000), "cm": Decimal(10), "mm": Decimal(1)}[unit]
                    value_mm = str(value * factor)
                dimensions.append(
                    Dimension(
                        axis=axis,
                        value=str(value),
                        unit=unit,
                        value_mm=value_mm,
                        original_text=measurement.text,
                        evidence_ids=[evidence_id],
                    )
                )
        # Unidad final compartida de una enumeración explícita de ejes.
        dimensional_candidates = [
            c
            for c in candidates
            if c.label in {"ANCHO", "ALTO", "PROFUNDIDAD", "LARGO", "DIAMETRO"}
        ]
        ordered = sorted(zip(dimensions, dimensional_candidates), key=lambda pair: pair[1].start)
        if len(ordered) >= 2 and ordered[-1][0].unit and all(not d.unit for d, _ in ordered[:-1]):
            start, end = ordered[0][1].start, ordered[-1][1].end
            remainder = text[start:end]
            for _, c in reversed(ordered):
                remainder = remainder[: c.start - start] + remainder[c.end - start :]
            # Sólo «45 ancho, 60 alto centímetros» declara una unidad
            # final fuera del valor. «120 de ancho y 75 cm de alto»
            # deja la primera medida sin unidad: no extrapolar la segunda.
            unidad_final = re.search(
                r"\b(?:ancho|anchura|alto|altura|profundo|profundidad|fondo|"
                r"largo|longitud|diametro|diámetro)\s+"
                r"(?:mm|cm|m|mil[ií]metros?|cent[ií]metros?|metros?)\s*$",
                ordered[-1][1].text,
                re.I,
            )
            if unidad_final and re.fullmatch(r"[\s,y]+", remainder, re.I):
                unit = ordered[-1][0].unit
                for d, _ in ordered[:-1]:
                    d.unit = unit
                    d.value_mm = str(Decimal(d.value) * {"m": 1000, "cm": 10, "mm": 1}[unit])
                    d.evidence_ids.extend(ordered[-1][0].evidence_ids)
                warnings = [w for w in warnings if w.code != "MISSING_UNIT"]
        thicknesses = []
        for thickness in find_thicknesses(text):
            if any(
                c.start <= thickness.start
                and thickness.end <= c.end
                and c.label in {"ANCHO", "ALTO", "PROFUNDIDAD", "LARGO", "DIAMETRO"}
                for c in candidates
            ):
                continue
            evidence_id = candidate(thickness)
            value, unit = thickness.value
            if unit is None:
                candidates[-1].decision = "UNRESOLVED"
                candidates[-1].reason = "Thickness unit is not explicit"
                warnings.append(
                    Warning(
                        code="MISSING_UNIT",
                        path="/item_proposal/thicknesses",
                        severity="REVIEW",
                        message="Confirm the thickness unit.",
                    )
                )
            thicknesses.append(
                Measurement(
                    value=str(value),
                    unit=unit,
                    value_mm=str(value * {"m": 1000, "cm": 10, "mm": 1}[unit]) if unit else None,
                    original_text=thickness.text,
                    evidence_ids=[evidence_id],
                )
            )
        accessories = []
        for accessory in find_accessories(text):
            if is_explicitly_negated(text, accessory.start):
                candidate(accessory, "REJECTED", "Accesorio explícitamente excluido")
                continue
            evidence = [candidate(accessory)]
            count = find_accessory_quantity(text, accessory.start, accessory.end)
            if count is not None:
                evidence.append(
                    candidate(
                        count,
                        "ACCEPTED" if count.value else "UNRESOLVED",
                        None if count.value else "Conflicting accessory counts",
                    )
                )
                if count.value is None:
                    warnings.append(
                        Warning(
                            code="CONFLICTING_VALUES",
                            path="/item_proposal/accessories",
                            severity="REVIEW",
                            message="Accessory quantity requires review.",
                        )
                    )
            accessories.append(
                Accessory(name=accessory.text, quantity=accessory.value, evidence_ids=evidence)
            )
        monetary_mentions, _ = price_mentions(text)
        price_match, price_mode = find_price(
            text, monetary_mentions, quantity_override=quantity.value if quantity else None
        )
        for mention, mention_mode in monetary_mentions:
            if price_match is None or mention.start != price_match.start:
                independent_total = (
                    price_match is not None
                    and price_mode == "PRECIO_UNITARIO"
                    and mention_mode == "TOTAL_NEGOCIADO"
                    and mention.value is not None
                    and not is_price_alternative(
                        text[
                            min(mention.end, price_match.end) : max(
                                mention.start, price_match.start
                            )
                        ]
                    )
                    and not is_price_correction(
                        text[
                            min(mention.end, price_match.end) : max(
                                mention.start, price_match.start
                            )
                        ]
                    )
                )
                if independent_total:
                    candidate(
                        Match(
                            mention.start,
                            mention.end,
                            mention.text,
                            "PRECIO_TOTAL",
                            money(mention.value),
                        )
                    )
                    if quantity is None:
                        warnings.append(
                            Warning(
                                code="REQUIRED_FIELD_MISSING",
                                path="/item_proposal/price",
                                severity="REVIEW",
                                message="Total y unitario explícitos conservados; falta cantidad para comprobar su relación.",
                            )
                        )
                    continue
                candidate(
                    mention,
                    "REJECTED" if price_match else "UNRESOLVED",
                    "Importe sustituido o reiterado"
                    if price_match
                    else "Importes incompatibles o inválidos",
                )
        if price_mode == "CONFLICTING_VALUES":
            warnings.append(
                Warning(
                    code="CONFLICTING_VALUES",
                    path="/item_proposal/price",
                    severity="REVIEW",
                    message="Hay varios precios sin rectificación inequívoca; confirme importe y modalidad.",
                )
            )
        # Un marcador ASR degradado no acredita la escala de un decimal
        # con punto. Conservar evidencia y exigir confirmación, sin multiplicar.
        if (
            price_match
            and re.search(
                r"\b(?:presionitario|presunitario|prese\s+unitario)\s*[,;:]?\s*$",
                text[: price_match.start],
                re.I,
            )
            and re.fullmatch(r"\d+\.\d{1,2}", price_match.text)
        ):
            candidate(price_match, "UNRESOLVED", "Escala monetaria incierta tras marcador ASR")
            warnings.append(
                Warning(
                    code="INVALID_PRICE",
                    path="/item_proposal/price",
                    severity="REVIEW",
                    message=f"Confirme el importe dictado {price_match.text}; no se infiere su escala.",
                )
            )
            price_match, price_mode = None, "REVIEW_PRICE"
        if price_mode is None:
            ambiguo = find_ambiguous_price(text)
            foreign_currency = (
                request.currency_context == "BOB"
                and re.search(r"\b(?:USD|d[oó]lares?)\b|\$", text, re.I)
                or request.currency_context == "USD"
                and re.search(r"\b(?:BOB|Bs|bolivianos?)\b", text, re.I)
            )
            if ambiguo and foreign_currency:
                candidate(ambiguo, "REJECTED", "Currency differs from commercial context")
                warnings.append(
                    Warning(
                        code="UNSUPPORTED_CURRENCY",
                        path="/item_proposal/price",
                        severity="REVIEW",
                        message="La moneda dictada no coincide con la proforma.",
                    )
                )
                ambiguo = None
            price_match = None
            if ambiguo:
                candidate(
                    ambiguo,
                    "UNRESOLVED",
                    "Inferred unit/total arithmetic equivalence for explicit quantity one; confirm price mode"
                    if quantity and quantity.value == 1
                    else "Commercial price mode is ambiguous",
                )
                warnings.append(
                    Warning(
                        code="REQUIRED_FIELD_MISSING",
                        path="/item_proposal/price",
                        severity="REVIEW",
                        message=(
                            f"Se dictó el importe {money(ambiguo.value)} "
                            f"{request.currency_context}; aclare si es total o precio unitario."
                        ),
                    )
                )
        price = None
        if price_mode == "INVALID_PRICE":
            warnings.append(
                Warning(
                    code="INVALID_PRICE",
                    path="/item_proposal/price",
                    severity="REVIEW",
                    message="El precio no tiene un formato válido completo.",
                )
            )
        elif price_match:
            currency_conflict = (
                request.currency_context == "BOB"
                and re.search(r"\b(?:USD|d[oó]lares?)\b|\$", text, re.I)
                or request.currency_context == "USD"
                and re.search(r"\b(?:BOB|Bs|bolivianos?)\b", text, re.I)
            )
            if currency_conflict:
                candidate(
                    price_match, "REJECTED", "La moneda dictada difiere del contexto comercial"
                )
                warnings.append(
                    Warning(
                        code="UNSUPPORTED_CURRENCY",
                        path="/item_proposal/price",
                        severity="REVIEW",
                        message="La moneda dictada no coincide con la proforma; indique el precio en su moneda.",
                    )
                )
                price_match = None
        if price_match and price_mode != "INVALID_PRICE":
            if any(w.code == "UNSUPPORTED_CURRENCY" for w in warnings):
                price_match = None
        if price_match and price_mode != "INVALID_PRICE":
            price_id = candidate(price_match)
            amount = money(price_match.value)
            if price_mode == "PRECIO_UNITARIO":
                total = money(price_match.value * quantity.value) if quantity else None
                price = UnitPrice(
                    mode="PRECIO_UNITARIO",
                    stated_amount=amount,
                    unit_price_input=amount,
                    line_total=total,
                    currency=request.currency_context,
                    origin="EXPLICIT_UNIT",
                    evidence_ids=[price_id],
                )
            else:
                reference = None
                approximate = False
                if quantity:
                    quotient = price_match.value / quantity.value
                    reference = f"{quotient.quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP):f}".rstrip(
                        "0"
                    ).rstrip(".")
                    approximate = Decimal(reference) * quantity.value != price_match.value
                price = NegotiatedPrice(
                    mode="TOTAL_NEGOCIADO",
                    stated_amount=amount,
                    line_total=amount,
                    currency=request.currency_context,
                    unit_price_reference=reference,
                    reference_is_approximate=approximate,
                    origin="EXPLICIT_TOTAL",
                    evidence_ids=[price_id],
                )
        tipo_candidato = re.sub(
            r"\s+para\s+(?:\d+|"
            + "|".join(
                (
                    "un",
                    "una",
                    "dos",
                    "tres",
                    "cuatro",
                    "cinco",
                    "seis",
                    "siete",
                    "ocho",
                    "nueve",
                    "diez",
                )
            )
            + r")\s+personas?\s*$",
            "",
            products[0].text,
            flags=re.I,
        )
        color_pendiente = re.search(
            r"\bcolor\s+(?:a\s+)?elecci[oó]n\b",
            text,
            re.I,
        )
        item = ItemProposal(
            name=products[0].text,
            furniture_type_candidate=tipo_candidato.lower(),
            quantity=quantity.value if quantity else None,
            dimensions=dimensions,
            thicknesses=thicknesses,
            accessories=accessories,
            price=price,
            observations=color_pendiente.group() if color_pendiente else None,
            unresolved=[c.candidate_id for c in candidates if c.decision == "UNRESOLVED"],
        )
        from homex_nlp.furniture_knowledge import commercial_family, enrich_knowledge
        from homex_nlp.semantics import completar_relaciones

        item.furniture_type_candidate = commercial_family(item.name)
        item = completar_relaciones(item, candidates, text, warnings)
        from homex_nlp.compositions import refine_relations

        item = refine_relations(item, candidates, text, warnings)
        enrich_knowledge(item, candidates, text, warnings)
        from homex_nlp.unit_inference import infer_units

        infer_units(item, candidates, text, warnings)
        return self._result(request, item, candidates, warnings, started)

    def _result(self, request, item, candidates, warnings, started):
        return ExtractionResult(
            request_id=request.request_id,
            status="REQUIRES_REVIEW" if item else "NO_PROPOSAL",
            text_original=request.text,
            item_proposal=item,
            proposed_item_count=int(item is not None),
            candidates=candidates,
            warnings=warnings,
            engine=EngineInfo(mode="RULES_ONLY", rules_version=self.rules_version),
            latency_nlp_ms=int((perf_counter() - started) * 1000),
        )
