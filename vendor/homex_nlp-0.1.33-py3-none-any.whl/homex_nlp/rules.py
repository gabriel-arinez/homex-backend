"""Reglas puras de F03; operan sobre el texto original y conservan offsets."""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from homex_nlp.furniture_knowledge import lexicon
from homex_nlp.monetary import AMOUNT, monetary_amount

NUMBER_WORDS = {
    "uno": 1,
    "un": 1,
    "una": 1,
    "dos": 2,
    "tres": 3,
    "cuatro": 4,
    "cinco": 5,
    "seis": 6,
    "siete": 7,
    "ocho": 8,
    "nueve": 9,
    "diez": 10,
}
PRODUCTS = (
    "escritorio",
    "mesa",
    "mueble",
    "librero",
    "estante",
    "credenza",
    "velador",
    "ropero",
    "closet",
    "clóset",
    "armario",
    "casillero",
    "cajonera",
    "gavetero",
    "gabetero",
    "atril",
    "vitrina",
    "sillón",
    "sillones",
)
PRODUCTS = (*PRODUCTS, *lexicon()["families"])

ACCESSORIES = (
    r"puertos?\s+(?:USB|HDMI)|conectores?(?:\s+(?:USB|HDMI))?|USB|HDMI|cajas?\s+el[eé]ctricas?|topes?\s+de\s+goma",
    "pasacable",
    "bisagras",
    r"caj[oó]n(?:es)?|gavetas?",
    "puertas",
    "jaladores",
    "tiradores",
    "ruedas",
    r"cerraduras?|chapas?(?:\s+de\s+seguridad)?",
    r"soportes?\s+lateral(?:es)?\s+para\s+CPU",
    "bandeja",
    "rieles",
    r"tapa\s*cantos?(?:\s+(?:de|en))?(?:\s+(?:PVC|P\.V\.C\.?))?",
    r"toma(?:s)?\s*corrientes?",
)

ACCESSORIES = (*ACCESSORIES, lexicon()["accessories"])


@dataclass(frozen=True)
class Match:
    start: int
    end: int
    text: str
    label: str
    value: object = None


def decimal_from_text(raw: str) -> Decimal | None:
    """Acepta formatos completos conocidos; rechaza ambigüedad en vez de truncar."""
    value = raw.strip().replace(" ", "")
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?", value):
        value = value.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?", value):
        value = value.replace(",", "")
    elif re.fullmatch(r"\d+(?:[,.]\d{1,2})?", value):
        value = value.replace(",", ".")
    else:
        return None
    try:
        parsed = Decimal(value)
    except InvalidOperation:
        return None
    return parsed if parsed > 0 else None


def money(value: Decimal) -> str:
    return f"{value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP):.2f}"


def is_explicitly_negated(text: str, start: int) -> bool:
    """Detecta exclusiones locales inequívocas sin normalizar el texto ni perder offsets.

    Un «no, mejor» introduce una corrección, no niega el producto que sigue.
    La cláusula termina en puntuación fuerte o coma; nunca se propaga
    una negación a toda la especificación.
    """
    clause = re.split(r"[.;,\n]", text[max(0, start - 140) : start])[-1]
    if re.search(
        r"\b(?:anul[aá]|anular|anule|anulo|cancel[aá]|cancelar|cancele|cancelo)"
        r"\s+(?:el\s+|este\s+)?(?:pedido|cotizaci[oó]n)\s+de\s+"
        r"(?:\d+|" + "|".join(NUMBER_WORDS) + r")\s*$",
        clause,
        re.I,
    ):
        return True
    matches = list(
        re.finditer(
            r"\b(?:sin|ni|no(?!-)(?:\s+(?:quiero|necesito|lleva|tiene|incluye|es|son))?)\b",
            clause,
            re.I,
        )
    )
    if not matches:
        return False
    negator = matches[-1].group().casefold()
    following = clause[matches[-1].end() :]
    # Una negación demasiado alejada no autoriza a descartar un producto.
    # «sin cajones y con puertas»: puertas sí están presentes.
    if re.search(r"\b(?:pero|con|mejor|s[ií]|quiero|necesito)\b", following, re.I):
        return False
    words = re.findall(r"\w+", following, re.UNICODE)
    if negator not in {"sin", "ni"} and "y" in words:
        # «No quiero dos mesas y un escritorio»: el segundo también puede
        # estar en el ámbito negado; no convertirlo en un pedido afirmativo.
        return len(words) <= 5
    limit = 3 if negator in {"sin", "ni"} else 2
    return len(words) <= limit


def find_products(text: str) -> list[Match]:
    # El núcleo se conserva corto: palabras libres absorbían «y una» o «a» y
    # ocultaban conflictos comerciales entre productos.
    pattern = re.compile(
        r"\b(?:"
        + "|".join(p + (r"(?:es)?" if p.endswith("r") else r"s?") for p in PRODUCTS)
        + r")\b(?:\s+en\s+l)?",
        re.I,
    )
    reunion = re.compile(
        r"\bmesas?\s+de\s+reuni[oó]n\b"
        r"(?:\s+para\s+(?:\d+|" + "|".join(NUMBER_WORDS) + r")\s+personas?)?",
        re.I,
    )
    # Variante ASR contextual: «escritor ejecutivo», no «escritor» aislado.
    ejecutivo_asr = re.compile(r"\bescritor(?:es)?\s+ejecutivos?\b", re.I)
    especificos = [
        Match(m.start(), m.end(), m.group(), "PRODUCTO")
        for patron in (
            reunion,
            ejecutivo_asr,
            re.compile(r"\bestante\s+librero\b|\bestantes\s+libreros\b", re.I),
            re.compile(
                r"\bcubos?\s+m[oó]vil(?:es)?\b|\bestaci(?:[oó]n|ones)\s+de\s+trabajo\b", re.I
            ),
        )
        for m in patron.finditer(text)
        if not (
            re.match(r"(?:estaci|cubo)", m.group(), re.I)
            and re.search(r"\bpara\s+(?:(?:los?|las?)\s+)?$", text[: m.start()], re.I)
        )
    ]
    # "Credencia" is a literal furniture noun, not an acoustic repair.
    especificos.extend(
        Match(m.start(), m.end(), m.group(), "PRODUCTO")
        for m in re.finditer(r"\bcredencias?\b", text, re.I)
        if _counted_furniture_context(text, m)
    )
    generales = [
        Match(m.start(), m.end(), m.group().strip(), "PRODUCTO")
        for m in pattern.finditer(text)
        if not any(x.start <= m.start() < x.end for x in especificos)
    ]
    # A finite ASR alias requires a counted technical furniture context.
    for alias in re.finditer(r"\bgadeteros?\b", text, re.I):
        counted = re.search(
            r"(?:\d+|un[ao]?|dos|tres|cuatro|cinco)\s+$", text[: alias.start()], re.I
        )
        technical = re.search(
            r"\b(?:(?:caj[oó]n(?:es)?|gavetas?)|melamina|tablero|ancho|alto|profundidad)\b",
            text[alias.end() : alias.end() + 220],
            re.I,
        )
        if counted and technical:
            generales.append(
                Match(alias.start(), alias.end(), alias.group(), "PRODUCTO", "gavetero")
            )
    results = sorted([*especificos, *generales], key=lambda x: x.start)
    extended = []
    for m in results:
        qualifier = re.match(
            r"(?:\s+(?:" + lexicon()["qualifiers"] + r")\b){1,4}", text[m.end :], re.I
        )
        end = m.end + qualifier.end() if qualifier else m.end
        extended.append(Match(m.start, end, text[m.start : end], m.label, m.value))
    return extended


def _counted_furniture_context(text: str, mention: re.Match[str]) -> bool:
    count = re.search(r"(" + _commercial_count_pattern() + r")\s+$", text[: mention.start()], re.I)
    if count is None or _commercial_count_match(text, count.start(1), count.end(1)) is None:
        return False
    dimension = re.match(
        r"\s+de\s+("
        + r"\d+(?:[.,]\d+)?|"
        + _DIM_PALABRAS_PATRON
        + r")\s*(?:cm|mm|m|metros?|cent[ií]metros?|mil[ií]metros?)\b",
        text[mention.end() :],
        re.I,
    )
    if dimension is None:
        return False
    raw = dimension.group(1)
    value = (
        decimal_from_text(raw)
        if re.fullmatch(r"\d+(?:[.,]\d+)?", raw)
        else _dimension_numero_palabras(raw)
    )
    return bool(
        value
        and value > 0
        and re.search(
            r"\b(?:melamina|MDP|MDF|madera)\b", text[mention.end() : mention.end() + 500], re.I
        )
    )


def _commercial_count_pattern() -> str:
    # Reuse the existing strict cardinal grammar, not the small legacy lexicon.
    return r"(?:\d+|" + _DIM_PALABRAS_PATRON + r")"


def _commercial_count_match(text: str, start: int, end: int) -> Match | None:
    before = text[:start]
    if re.search(r"[-−+]\s*$|\d[.,]\s*$|\b(?:menos|o)\s*$", before, re.I):
        return None
    if _fragmento_numerico_truncado(text, start):
        return None
    raw = text[start:end]
    value = int(raw) if raw.isdecimal() else _dimension_numero_palabras(raw)
    if value is None or value <= 0:
        return None
    return Match(start, end, raw, "CANTIDAD", int(value))


def _cantidad_comercial_pospuesta(text: str, principal: Match) -> Match | None:
    """Cantidad contigua al producto, sin consumir especificaciones de piezas.

    «mesa de reunión para diez personas, una pieza tamaño ...» describe una
    unidad comercial; «mesa, una pieza de vidrio» no es concluyente.
    Ante una rectificación de la misma cantidad sin puntuación, abstenerse.
    """
    tramo = text[principal.end : principal.end + 180]
    inicio = re.match(
        r"\s*[,;:]?\s*(?P<numero>" + _commercial_count_pattern() + r")"
        r"\s+(?P<unidad>piezas?|pzas?\.?|unidades?|juegos?)\b",
        tramo,
        re.I,
    )
    if inicio is None:
        return None
    count = _commercial_count_match(
        text, principal.end + inicio.start("numero"), principal.end + inicio.end("numero")
    )
    if count is None:
        return None
    despues = tramo[inicio.end() :]
    # «una pieza de vidrio», «dos piezas para el tablero»: componentes, no
    # líneas comerciales. No consumirlas para inferir importes.
    if re.match(r"\s+(?:de|del|para)\b", despues, re.I):
        # «dos unidades de 1.50 metros de ancho» declara cantidad
        # comercial seguida de la dimensión del mismo mueble.
        # «dos piezas de vidrio» y «dos unidades de 18 mm» no.
        dimension_del_mueble = re.match(
            r"\s+de\s+\d+(?:[.,]\d+)?\s*"
            r"(?:m(?:etros?)?|cm|cent[ií]metros?)\s+"
            r"de\s+(?:ancho|alto|largo|profundidad|fondo)\b",
            despues,
            re.I,
        )
        if not dimension_del_mueble:
            return None
    # Una rectificación posterior de la misma magnitud exige arbitraje;
    # nunca conservar por defecto la primera cifra como comercial.
    if re.match(
        r"\s*[,;.]?\s*(?:no\s*,?\s*(?:mejor|\d+|"
        + _commercial_count_pattern()
        + r")|perd[oó]n|corrijo|mejor)\b",
        despues,
        re.I,
    ):
        return None
    return count


def find_quantity(text: str, main_product: Match | None = None) -> Match | None:
    products = [main_product] if main_product is not None else find_products(text)
    if not products:
        return None
    main = products[0]
    prefix = text[: main.start]
    pattern = re.compile(
        r"(?<![\w.,+\-−])("
        + _commercial_count_pattern()
        + r")\s+(?:(?:juegos?|unidades?)\s+(?:de\s+)?)?$",
        re.I,
    )
    match = pattern.search(prefix)
    if match:
        return _commercial_count_match(text, match.start(1), match.end(1))
    # La cantidad comercial se reconoce sólo en construcciones inequívocas.
    # «para 10 personas» y «2 tomacorrientes» no son cantidad de muebles.
    explicit = re.search(
        r"\b(?:cantidad(?:\s+comercial)?\s*(?::|de)?\s*|se\s+cotizan\s+)"
        r"(" + _commercial_count_pattern() + r")\s*"
        r"(?:piezas?|pzas?\.?|unidades?|juegos?)\b",
        text,
        re.I,
    )
    if explicit:
        return _commercial_count_match(text, explicit.start(1), explicit.end(1))
    # «se cotiza una sola mesa» declara una unidad, no un segundo producto.
    # Aceptar únicamente el mismo tipo principal, sin extrapolar cantidades.
    if main.text.casefold().startswith("mesa"):
        una_sola = re.search(
            r"\b(?:se\s+cotiza|secotiza)\s+(una)\s+sola\s+mesa\b",
            text[main.end :],
            re.I,
        )
        if una_sola:
            start = main.end + una_sola.start(1)
            return Match(start, start + 3, text[start : start + 3], "CANTIDAD", 1)
    return _cantidad_comercial_pospuesta(text, main)


def _numero_es_medida_no_precio(text: str, encontrado: re.Match[str]) -> bool:
    """Nunca convertir medidas dimensionales explícitas en precios comerciales.

    Mantener los offsets del texto original; no depende de normalización ASR.
    No bloquea importes sin moneda cuando el contexto comercial es claro.
    """
    unidad_dimension = (
        r"(?:mm|cm|m|mts?|mil[ií]metros?|cent[ií]metros?|metros?|"
        r"pulgadas?|pies)\b"
    )
    if re.match(r"\s*" + unidad_dimension, text[encontrado.end(1) :], re.I):
        return True
    anterior = text[max(0, encontrado.start() - 42) : encontrado.start()]
    return bool(
        re.search(
            r"\b(?:ancho|anchura|alto|altura|largo|longitud|fondo|"
            r"profundidad|di[aá]metro|espesor)\s*$",
            anterior,
            re.I,
        )
        and encontrado.group().casefold().lstrip().startswith("total")
    )


def price_mentions(text: str):
    """Precios comerciales explícitos; nunca convertir un total en unitario aquí.

    Una medida como «ancho total 180 centímetros» NO es «Bs 180».
    Si aparece un precio real después de una medida, seguir buscándolo.
    """
    moneda = r"(?:bs\.?|bob|bolivianos?|bolivios?|d[oó]lares?|usd)"

    def primero_aplicable(patron: str):
        return [
            encontrado
            for encontrado in re.finditer(patron, text, re.I)
            if not _numero_es_medida_no_precio(text, encontrado)
        ]

    unit = primero_aplicable(
        r"(?<![\w.,−-])(?:a\s+|por\s+)?(" + AMOUNT + r")\s*(?:" + moneda + r"\s*)?"
        r"(?:cada\s+un[ao]|c/u|por\s+unidad)\b"
    )
    declared_unit = primero_aplicable(
        r"\b(?:precio\s+(?:por\s+(?:unidad|juego|pieza|barra|metro\s+cuadrado)|unitario|de\s+lista)|"
        r"precio\s+de\s+lista|"
        r"valor\s+unitario|"
        r"presionitario|presiunitario|preciunitario|presunitario|prese\s+unitario)"
        r"\s*[,;:]?\s*(?:(?:es\s+de|es|de)\s+)?(?:" + moneda + r"\s*)?(" + AMOUNT + r")\b"
    )
    cantidad = r"(?:\d+|" + "|".join(NUMBER_WORDS) + r")"
    tipo = r"(?:mesas?|escritorios?|veladores?|muebles?|roperos?|libreros?|credenzas?|estantes?)"
    total = primero_aplicable(
        r"\b(?:precio\s+total(?:\s+negociado)?|total(?:\s+negociado)?|monto(?:\s+total)?)"
        r"(?:\s+de\s+(?:las?|los?)\s+" + cantidad + r"\s+" + tipo + r")?"
        r"\s*[,;:]?\s*(?:(?:es|de)\s+)*(?:" + moneda + r"\s*)?(" + AMOUNT + r")\b"
    )
    mentions = sorted(
        [(m, "PRECIO_UNITARIO") for m in unit + declared_unit]
        + [
            (m, "TOTAL_NEGOCIADO")
            for m in total
            + primero_aplicable(
                r"(?<![\w.,−-])(?:por\s+)?(" + AMOUNT + r")\s*(?:" + moneda + r"\s+)?en\s+total\b"
            )
        ],
        key=lambda pair: pair[0].start(1),
    )
    # Currency or a commercial marker establishes evidence, not a spoken mode.
    ambiguous = primero_aplicable(
        r"(?<![\w.,−-])(" + AMOUNT + r")\s*" + moneda + r"\b"
    ) + primero_aplicable(
        r"\bprecio\s+(?!(?:unitario|total|por|de\s+lista)\b)(?:(?:es|de)\s+)?(" + AMOUNT + r")"
    )
    explicit = list(mentions)
    mentions += [
        (m, "PRECIO_AMBIGUO")
        for m in ambiguous
        if not any(
            (m.start(1) < known.end(1) and known.start(1) < m.end(1))
            or (known.end(1) <= m.start(1) and is_price_correction(text[known.end(1) : m.start(1)]))
            for known, _ in explicit
        )
    ]
    mentions.sort(key=lambda pair: pair[0].start(1))
    unique = {}
    for m, mode in mentions:
        raw = m.group(1).rstrip(".,")
        # Un signo menos no puede desaparecer al buscar el primer dígito.
        negative = re.search(r"[-−]\s*$", text[m.start() : m.start(1)])
        value = None if negative else monetary_amount(raw, decimal_from_text)
        unique[(m.start(1), m.start(1) + len(raw))] = (
            Match(m.start(1), m.start(1) + len(raw), raw, "PRECIO", value),
            mode,
        )
    values = list(unique.values())
    if not values:
        return [], None
    # Una corrección sin repetir modalidad hereda únicamente el marcador
    # inequívoco anterior; cada valor cancelado conserva su span original.
    expanded = []
    for mention, mode in values:
        expanded.append((mention, mode))
        tail = text[mention.end :]
        correction = re.match(
            r"\s*(?:bolivianos?|d[oó]lares?|BOB|USD|Bs\.?)?\s*[,;]?\s*"
            r"(?:corrijo|perd[oó]n|no\s*,?\s*mejor)\s*[,;:]?\s*(?:de\s+)?"
            r"(?P<amount>" + AMOUNT + r")",
            tail,
            re.I,
        )
        while correction:
            start = mention.end + correction.start("amount")
            raw = correction.group("amount").rstrip(".,")
            if re.match(
                r"\s*(?:mm|cm|m|mil[ií]metros?|cent[ií]metros?|metros?)\b",
                text[start + len(raw) :],
                re.I,
            ):
                return expanded + [
                    (Match(start, start + len(raw), raw, "PRECIO", None), mode)
                ], None
            mention = Match(
                start, start + len(raw), raw, "PRECIO", monetary_amount(raw, decimal_from_text)
            )
            expanded.append((mention, mode))
            tail = text[mention.end :]
            correction = re.match(
                r"\s*[,;]?\s*(?:corrijo|perd[oó]n|no\s*,?\s*mejor)"
                r"\s*[,;:]?\s*(?:de\s+)?(?P<amount>" + AMOUNT + r")",
                tail,
                re.I,
            )
    values = sorted(
        {(m.start, m.end): (m, mode) for m, mode in expanded}.values(), key=lambda p: p[0].start
    )
    return values, None


def is_price_correction(fragment: str) -> bool:
    """La corrección debe conectar importes, no una rectificación de otra pieza."""
    return bool(
        re.fullmatch(
            r"\s*(?:bolivianos?|d[oó]lares?|BOB|USD|Bs\.?)?\s*[,;.]?\s*"
            r"(?:corrijo|perd[oó]n|no\s*,?\s*mejor)\s*[,;:]?\s*"
            r"(?:(?:precio\s+(?:unitario|total(?:\s+negociado)?)|valor\s+unitario|total(?:\s+negociado)?)\s+)?"
            r"(?:de\s+)?(?:bolivianos?|d[oó]lares?|BOB|USD|Bs\.?)?\s*",
            fragment,
            re.I,
        )
    )


def is_price_alternative(fragment: str) -> bool:
    """Alternativa entre precios; una «o» dentro de un color no cambia el precio."""
    return bool(
        re.fullmatch(
            r"\s*(?:bolivianos?|d[oó]lares?|BOB|USD|Bs\.?)?\s*[,;]?\s+o\s+"
            r"(?:(?:precio\s+(?:unitario|total(?:\s+negociado)?)|total)\s+)?"
            r"(?:de\s+)?(?:bolivianos?|d[oó]lares?|BOB|USD|Bs\.?)?\s*",
            fragment,
            re.I,
        )
    )


def find_price(text: str, mentions=None, quantity_override=...) -> tuple[Match | None, str | None]:
    if mentions is None:
        mentions, _ = price_mentions(text)
    if not mentions:
        return None, None
    if any(m.value is None or is_explicitly_negated(text, m.start) for m, _ in mentions):
        return None, "INVALID_PRICE"
    for kind in ("PRECIO_UNITARIO", "TOTAL_NEGOCIADO", "PRECIO_AMBIGUO"):
        same_kind = [m for m, k in mentions if k == kind]
        for a, b in zip(same_kind, same_kind[1:]):
            if a.value != b.value and not is_price_correction(text[a.end : b.start]):
                return None, "CONFLICTING_VALUES"
    current, mode = mentions[0]
    for following, following_mode in mentions[1:]:
        between = text[current.end : following.start]
        correction = is_price_correction(between)
        if correction:
            current, mode = following, following_mode
        elif following.value != current.value or following_mode != mode:
            if "PRECIO_AMBIGUO" in {mode, following_mode}:
                return None, "CONFLICTING_VALUES"
            # Dos modalidades explícitas pueden corroborarse aritméticamente;
            # no se deriva un unitario nuevo de un total ni se inventa descuento.
            quantity = find_quantity(text) if quantity_override is ... else None
            quantity_value = (
                quantity.value
                if quantity
                else (None if quantity_override is ... else quantity_override)
            )
            if (
                following_mode != mode
                and quantity_value is None
                and not is_price_alternative(between)
            ):
                # Ambos importes son literales independientes. La falta de
                # cantidad impide comprobar su relación, no invalida el unitario.
                current = current if mode == "PRECIO_UNITARIO" else following
                mode = "PRECIO_UNITARIO"
                continue
            if (
                following_mode != mode
                and not is_price_alternative(between)
                and quantity_value
                and not re.search(r"\bdescuento\s+(?!cero\b|0\b)\d", text, re.I)
            ):
                unit = current if mode == "PRECIO_UNITARIO" else following
                total = following if mode == "PRECIO_UNITARIO" else current
                if unit.value * quantity_value == total.value:
                    current, mode = unit, "PRECIO_UNITARIO"
                    continue
            return None, "CONFLICTING_VALUES"
    return current, None if mode == "PRECIO_AMBIGUO" else mode


def find_ambiguous_price(text: str) -> Match | None:
    """Conserva evidencia de «precio 7300» sin inventar su modalidad."""
    match, mode = find_price(text)
    if match is None or mode is not None:
        return None
    return Match(match.start, match.end, match.text, "PRECIO_AMBIGUO", match.value)


# Valores dimensionales en palabras del ASR. Intencionadamente no se incorpora
# al lector general de precios/cantidades: una palabra sólo es una medida si
# aparece acompañada de eje explícito y unidad de longitud reconocida.
_DIM_UNIDADES = {
    "un": 1,
    "uno": 1,
    "una": 1,
    "dos": 2,
    "tres": 3,
    "cuatro": 4,
    "cinco": 5,
    "seis": 6,
    "siete": 7,
    "ocho": 8,
    "nueve": 9,
}
_DIM_CORTOS = {
    "diez": 10,
    "once": 11,
    "doce": 12,
    "trece": 13,
    "catorce": 14,
    "quince": 15,
    "dieciseis": 16,
    "diecisiete": 17,
    "dieciocho": 18,
    "diecinueve": 19,
    "veinte": 20,
    "veintiuno": 21,
    "veintiun": 21,
    "veintiuna": 21,
    "veintidos": 22,
    "veintitres": 23,
    "veinticuatro": 24,
    "veinticinco": 25,
    "veintiseis": 26,
    "veintisiete": 27,
    "veintiocho": 28,
    "veintinueve": 29,
}
_DIM_DECENAS = {
    "treinta": 30,
    "cuarenta": 40,
    "cincuenta": 50,
    "sesenta": 60,
    "setenta": 70,
    "ochenta": 80,
    "noventa": 90,
}
_DIM_CENTENAS = {
    "cien": 100,
    "ciento": 100,
    "doscientos": 200,
    "doscientas": 200,
    "trescientos": 300,
    "trescientas": 300,
    "cuatrocientos": 400,
    "cuatrocientas": 400,
    "quinientos": 500,
    "quinientas": 500,
    "seiscientos": 600,
    "seiscientas": 600,
    "setecientos": 700,
    "setecientas": 700,
    "ochocientos": 800,
    "ochocientas": 800,
    "novecientos": 900,
    "novecientas": 900,
}


def _dimension_numero_palabras(raw: str) -> Decimal | None:
    """Read bounded spelled cardinal values through the shared scalar grammar."""
    from homex_nlp.magnitudes import scalar

    if re.search(r"\d", raw) or len(raw.split()) > 7:
        return None
    value = scalar(raw)
    return value if value is not None and 1 <= value <= 9999 else None


# La gramática se acota mediante léxico explícito. «y» sólo se acepta dentro
# de una decena compuesta; la función numérica valida la secuencia íntegra.
_DIM_LEXICO = (
    set(_DIM_UNIDADES)
    | set(_DIM_CORTOS)
    | set(_DIM_DECENAS)
    | set(_DIM_CENTENAS)
    | {"mil", "y", "dieciséis", "veintidós", "veintitrés", "veintiséis", "veintiún"}
)
_DIM_PALABRAS_PATRON = (
    r"\b(?:"
    + "|".join(sorted(_DIM_LEXICO - {"y"}, key=len, reverse=True))
    + r")\b"
    + r"(?:\s+(?:"
    + "|".join(sorted(_DIM_LEXICO, key=len, reverse=True))
    + r")\b){0,6}"
)


def _fragmento_numerico_truncado(text: str, start: int) -> bool:
    """Impide que se tome sólo el sufijo de una expresión numérica inválida."""
    import unicodedata

    # An explicit clause separator terminates the preceding numeric expression.
    # Keep same-clause malformed compounds blocked rather than consuming a suffix.
    if re.search(r"[,;:.!?]\s*$", text[:start]):
        return False
    contexto = "".join(
        char
        for char in unicodedata.normalize("NFD", text[max(0, start - 40) : start].casefold())
        if unicodedata.category(char) != "Mn"
    )
    anterior = re.findall(r"\w+", contexto)
    if (
        len(anterior) >= 2
        and anterior[-1] == "y"
        and (
            anterior[-2] in _DIM_LEXICO
            or anterior[-2] in {"metro", "metros", "centimetro", "centimetros", "cm", "mm"}
        )
    ):
        return True
    if (
        len(anterior) >= 2
        and anterior[-1] in {"coma", "punto", "con"}
        and (anterior[-2] in _DIM_LEXICO or anterior[-2].isdigit())
    ):
        return True
    if anterior and anterior[-1] in _DIM_LEXICO and anterior[-1] != "y":
        return True
    return False


def _medidas_orales_compuestas(text: str, axis: str, axis_prefix: str, unit: str):
    """Metros enteros + resto centimétrico, con eje explícito y span íntegro.

    Elipsis «un metro veinte/20»: sólo restos 10..99 sin conjunción. Con
    «y» se exige centímetros explícitos; no adivinar «un metro y cinco».
    Se devuelven también spans inválidos para impedir que los lectores simples
    acepten sólo «20 de ancho» o «ancho un metro» de una expresión compuesta.
    """
    from homex_nlp.magnitudes import COMPOUND, length

    patterns = (
        re.compile(axis + axis_prefix + "(?P<length>" + COMPOUND + ")", re.I),
        re.compile(
            r"(?<![\w.,+−-])(?P<length>" + COMPOUND + r")\s+(?:de\s+)?" + axis + r"\b", re.I
        ),
    )
    found, spans = [], []
    for pattern in patterns:
        for match in pattern.finditer(text):
            # A conjunction followed by an internal count is not a malformed
            # compound length; preserve the simple preceding metre measure.
            if re.search(r"\s+y\s+", match.group("length"), re.I) and re.match(
                r"\s+(?:(?:caj[oó]n(?:es)?|gavetas?)|puertas?|ruedas?|repisas?)\b",
                text[match.end() :],
                re.I,
            ):
                continue
            spans.append((match.start(), match.end()))
            if match.end() == match.end("length") and re.match(
                r"\s+y\s+(?:" + _DIM_PALABRAS_PATRON + r"|\d+)\s*(?:" + unit + r")?",
                text[match.end() :],
                re.I,
            ):
                continue
            if _fragmento_numerico_truncado(text, match.start("length")) or is_explicitly_negated(
                text, match.start()
            ):
                continue
            value, normalized = length(match.group("length"))
            if value is not None:
                found.append(
                    Match(match.start(), match.end(), match.group(), "", (value, normalized))
                )
    return found, spans


def find_measurements(text: str, label: str) -> list[Match]:
    axes = {
        "ancho": "ancho|anchura",
        "alto": "alto|altura",
        "profundidad": "profundidad|profundo|fondo",
        "largo": "largo|longitud",
        "diametro": "di[aá]metro",
    }
    axis = "(?:" + axes.get(label, label) + ")"
    unit = r"(?:mil[ií]metros?|cent[ií]metros?|metros?|mm|cm|mts?|m)\b"
    # «profundidad de cubierta de 0.60 metros» es una medida explícita.
    # No aceptar calificadores abiertos ni extrapolar a otros ejes.
    axis_prefix = (
        r"\s*(?:de\s+(?:cubierta|tablero)\s+)?(?:de\s+)?(?:total\s+)?"
        if label == "profundidad"
        else r"\s*(?:de\s+)?(?:total\s+)?"
    )
    forward_pattern = re.compile(
        axis + axis_prefix + r"(\d+(?:[.,]\d+)*)\s*(" + unit + r")?",
        re.I,
    )
    inverse_pattern = re.compile(
        r"(\d+(?:[.,]\d+)*)\s*(" + unit + r")?\s*(?:de\s+)?" + axis + r"(?:\s+(" + unit + r"))?",
        re.I,
    )
    compuestas, spans_compuestos = _medidas_orales_compuestas(text, axis, axis_prefix, unit)
    found = []
    for match in [*forward_pattern.finditer(text), *inverse_pattern.finditer(text)]:
        inverse = match.re is inverse_pattern
        other_axis = (
            r"(?:ancho|anchura|alto|altura|largo|longitud|profundidad|fondo|di[aá]metro|espesor)"
        )
        if (
            inverse
            and re.search(
                other_axis + axis_prefix + r"$",
                text[max(0, match.start() - 50) : match.start()],
                re.I,
            )
            and not re.search(r"\bde\s+" + axis + r"\b", match.group(), re.I)
        ):
            continue
        if re.search(r"[-−]\s*$", text[max(0, match.start() - 3) : match.start()]):
            continue
        raw_value = match.group(1)
        value = (
            Decimal(raw_value.replace(",", "."))
            if re.fullmatch(r"\d+(?:[.,]\d+)?", raw_value)
            else None
        )
        if value is not None and value <= 0:
            value = None
        raw_unit = match.group(2) or (match.group(3) if inverse else None)
        if value is not None:
            normalized = None
            if raw_unit:
                token = raw_unit.casefold()
                normalized = (
                    "mm"
                    if token.startswith(("mili", "milí")) or token == "mm"
                    else "cm"
                    if token.startswith("cent") or token == "cm"
                    else "m"
                )
            found.append(
                Match(match.start(), match.end(), match.group(), label.upper(), (value, normalized))
            )

    # Sólo los valores en palabras con unidad inequívoca y eje explícito.
    # La ruta preexistente de dígitos queda sin alteración alguna.
    palabras_eje = re.compile(
        axis + r"\s*(?:de\s+)?(?:total\s+)?(" + _DIM_PALABRAS_PATRON + r")\s+(" + unit + r")",
        re.I,
    )
    palabras_invertido = re.compile(
        r"(" + _DIM_PALABRAS_PATRON + r")\s+(" + unit + r")\s*(?:de\s+)?" + axis + r"\b",
        re.I,
    )
    for patron in (palabras_eje, palabras_invertido):
        for coincidencia in patron.finditer(text):
            if patron is palabras_invertido and _fragmento_numerico_truncado(
                text, coincidencia.start(1)
            ):
                continue
            valor = _dimension_numero_palabras(coincidencia.group(1))
            if valor is None:
                continue
            unidad = coincidencia.group(2).casefold()
            normalizada = (
                "mm"
                if unidad.startswith(("mili", "milí")) or unidad == "mm"
                else "cm"
                if unidad.startswith("cent") or unidad == "cm"
                else "m"
            )
            found.append(
                Match(
                    coincidencia.start(),
                    coincidencia.end(),
                    coincidencia.group(),
                    label.upper(),
                    (valor, normalizada),
                )
            )
    # Preserve unitless spoken values, but never fabricate their unit here.
    for pattern_words in (
        re.compile(r"(" + _DIM_PALABRAS_PATRON + r")\s+(?:de\s+)?" + axis + r"\b", re.I),
    ):
        for match in pattern_words.finditer(text):
            # In "una altura de 73 cm", una is an article introducing the
            # following measurement, not a second unitless height of one.
            if re.fullmatch(r"un[ao]?", match.group(1), re.I) and re.match(
                r"\s+de\s+", text[match.end() :], re.I
            ):
                continue
            value = _dimension_numero_palabras(match.group(1))
            if (
                value
                and not _fragmento_numerico_truncado(text, match.start(1))
                and not re.search(
                    r"\b(?:metros?|cm|mm|cent[ií]metros?)\s+$", text[: match.start(1)], re.I
                )
                and not any(m.start <= match.start() and match.end() <= m.end for m in found)
            ):
                found.append(
                    Match(match.start(), match.end(), match.group(), label.upper(), (value, None))
                )
    found = [m for m in found if not any(a <= m.start and m.end <= b for a, b in spans_compuestos)]
    found.extend(Match(m.start, m.end, m.text, label.upper(), m.value) for m in compuestas)
    # A preceding product adjective cannot override the axis explicitly following
    # the same value (armario alto de80cm de ancho).
    opposite = r"(?:ancho|anchura|alto|altura|largo|longitud|profundidad|fondo|di[aá]metro|espesor)"
    filtered = []
    for measurement in found:
        tail_axis = re.match(r"\s+(?:de\s+)?(" + opposite + r")\b", text[measurement.end :], re.I)
        forward_axis = re.match(axis + r"\b", measurement.text, re.I)
        if forward_axis and re.search(
            r"(?:\d+(?:[.,]\d+)*|" + _DIM_PALABRAS_PATRON + r")\s*(?:" + unit + r")?\s+de\s+$",
            text[max(0, measurement.start - 200) : measurement.start],
            re.I,
        ):
            # An explicit postfix axis belongs to the preceding value, even
            # when another value follows it without ASR punctuation.
            continue
        if (
            forward_axis
            and tail_axis
            and not re.fullmatch(axis, tail_axis.group(1), re.I)
            and (
                re.match(r"\s+de\s+", tail_axis.group(), re.I)
                or not re.match(
                    axis_prefix + r"(?:\d|" + _DIM_PALABRAS_PATRON + r")",
                    text[measurement.end + tail_axis.end() :],
                    re.I,
                )
            )
        ):
            continue
        filtered.append(measurement)
    if label == "alto":
        filtered = [
            m
            for m in filtered
            if not re.search(
                r"\b(?:a|hasta)\s+media\s*$", text[max(0, m.start - 25) : m.start], re.I
            )
        ]
    return sorted(filtered, key=lambda encontrada: encontrada.start)


def board_gauge_context(text: str, start: int, *, full: bool = False) -> bool:
    """A bounded literal board description, allowing a brand and an ASR pause."""
    return bool(
        (re.fullmatch if full else re.search)(
            r"\b(?:melamina|me\s+lamina|melam[eéíi]nic[oa]|mdf|mdp|hdf|tablero|tapa|"
            r"tapacantos?|tapa\s+cantos?|PVC|ABS|cubierta|estructura|mes[oó]n|me\s+son|"
            r"fald[oó]n|laterales?|panel(?:es)?|superficie\s+auxiliar)"
            r"(?:\s+(?:de|melamina|MDF|MDP|PVC|ABS|blanc[oa]|negr[oa]|melam[eéíi]nic[oa]|"
            r"menam[ií]nic[oa]|engrosad[oa]|frontal|superior|Novopan|nobopan|novo\s+pan)){0,5}"
            r"\s*,?\s*(?:(?:de|a)\s+)?$",
            text[max(0, start - 150) : start],
            re.I,
        )
    )


def find_thicknesses(text: str) -> list[Match]:
    """Only a thickness marker or a board substrate licenses thickness."""
    from homex_nlp.magnitudes import NUMBER, UNIT, length

    found = []
    # A shared final unit may qualify two complete cardinals, but never split
    # the cardinal itself ("treinta y seis" is one number).
    from homex_nlp.magnitudes import scalar, unit_name

    shared_spans = []
    shared = re.compile(
        r"\b(?:melamina|tablero|mes[oó]n|MDF|MDP)\s+(?:de\s+)?(?P<amount>"
        + AMOUNT
        + r")\s*(?P<unit>"
        + UNIT
        + r")",
        re.I,
    )
    for enumeration in shared.finditer(text):
        raw = enumeration.group("amount").strip()
        if scalar(raw) is not None:
            continue
        splits = []
        for separator in re.finditer(r"\s+y\s+", raw, re.I):
            left, right = raw[: separator.start()].strip(), raw[separator.end() :].strip()
            a, b = scalar(left), scalar(right)
            if a and b:
                splits.append((left, right, a, b, separator))
        if len(splits) != 1:
            continue
        left, right, a, b, separator = splits[0]
        start = enumeration.start("amount")
        right_start = start + separator.end()
        unit = unit_name(enumeration.group("unit"))
        found.extend(
            [
                Match(
                    start, start + len(left), text[start : start + len(left)], "ESPESOR", (a, unit)
                ),
                Match(
                    right_start,
                    enumeration.end(),
                    text[right_start : enumeration.end()],
                    "ESPESOR",
                    (b, unit),
                ),
            ]
        )
        shared_spans.append((enumeration.start(), enumeration.end()))
    pattern = re.compile(r"\b(?P<value>" + NUMBER + r")\s*(?P<unit>" + UNIT + r")?", re.I)
    for match in pattern.finditer(text):
        if any(a <= match.start() < b for a, b in shared_spans):
            continue
        before = text[max(0, match.start() - 65) : match.start()]
        after = text[match.end() : match.end() + 30]
        explicit = re.search(
            r"\b(?:espesor|grosor|engrosad[oa]|fald[oó]n\s+a\s+media\s+altura)\s*(?:(?:de|a)\s+)?$",
            before,
            re.I,
        ) or re.match(r"\s+(?:de\s+)?(?:espesor|grosor)\b", after, re.I)
        board = board_gauge_context(text, match.start())
        continuation = found and re.fullmatch(
            r"\s*(?:y\s+|,?\s*(?:perd[oó]n|corrijo|mejor)\s*,?\s*(?:de\s+)?)",
            text[found[-1].end : match.start()],
            re.I,
        )
        from homex_nlp.thickness_context import contextual_gauge

        contextual = contextual_gauge(text, match.start(), match.end())
        if not (explicit or (board or continuation) and match.group("unit") or contextual):
            continue
        value, unit = length(match.group())
        if not explicit and re.match(
            r"\s*(?:de\s+)?(?:largo|longitud|ancho|alto|fondo|profundidad|bolivianos|d[oó]lares)\b",
            after,
            re.I,
        ):
            continue
        if unit is None and not explicit and (value is None or not Decimal("0.5") <= value <= 60):
            continue
        if (
            value
            and (continuation or not _fragmento_numerico_truncado(text, match.start()))
            and not is_explicitly_negated(text, match.start())
        ):
            found.append(Match(match.start(), match.end(), match.group(), "ESPESOR", (value, unit)))
    return found


def find_accessories(text: str) -> list[Match]:
    pattern = re.compile(
        r"\b(?:"
        + "|".join(ACCESSORIES)
        + r")\b(?:\s+(?!(?:y|con|pero|sin|color|precio)\b)(?!(?:"
        + "|".join(ACCESSORIES)
        + r")\b)(?!(?:"
        + "|".join(NUMBER_WORDS)
        + r")\b)[a-záéíóúñ]+){0,3}",
        re.I,
    )
    encontrados = []
    for match in pattern.finditer(text):
        texto_accesorio = match.group().strip()
        # El ASR a menudo omite la coma antes de otra cláusula:
        # «dos tomacorrientes al centro estructura en tablero».
        # No eliminar «estructura» si es objeto de «de/en/para/con», pues
        # puede ser una descripción propia de un accesorio.
        for nuevo_campo in re.finditer(
            r"\b(?:estructura|precio|dimensiones?)\b", texto_accesorio, re.I
        ):
            if nuevo_campo.start() == 0:
                continue
            prefijo_palabra = re.search(r"\b(\w+)\s+$", texto_accesorio[: nuevo_campo.start()])
            if (
                nuevo_campo.group().casefold() == "estructura"
                and prefijo_palabra
                and prefijo_palabra.group(1).casefold() in {"de", "del", "en", "para", "con"}
            ):
                continue
            texto_accesorio = texto_accesorio[: nuevo_campo.start()].rstrip()
            break
        texto_accesorio = re.sub(
            r"(?:\s+(?:de|del|en|con|para|por|a|al))+$",
            "",
            texto_accesorio,
            flags=re.I,
        )
        encontrados.append(
            Match(
                match.start(),
                match.start() + len(texto_accesorio),
                texto_accesorio,
                "ACCESORIO",
                quantity.value
                if (
                    quantity := find_accessory_quantity(
                        text, match.start(), match.start() + len(texto_accesorio)
                    )
                )
                else None,
            )
        )
    return encontrados


def find_accessory_quantity(text: str, start: int, end: int) -> Match | None:
    """Only explicit adjacent integer counts; protocol numbers are not quantities."""
    number = r"(?!y\b)" + AMOUNT
    prefix_start = max(0, start - 200)
    prefix = re.search(r"(?<![\w.,−-])(" + number + r")\s*$", text[prefix_start:start], re.I)
    suffix = re.match(
        r"\s*(?:\(\s*|:\s*)(" + number + r")(?:\s+unidades?)?\s*(?:\)|[,.;]|$)"
        r"|\s*,\s*(" + number + r")\s+unidades?\b",
        text[end : end + 200],
        re.I,
    )
    found = []
    for match, offset in [(prefix, prefix_start), (suffix, end)]:
        if match is None:
            continue
        group = 1 if match.group(1) else 2
        raw = match.group(group)
        number_start = offset + match.start(group)
        if re.search(r"\b(?:o|menos)\s*$", text[max(0, number_start - 200) : number_start], re.I):
            continue
        if (
            prefix_start
            and offset + match.start(group) == prefix_start
            and text[prefix_start - 1].isalnum()
        ):
            continue
        parsed = Decimal(raw) if raw.isdigit() else _dimension_numero_palabras(raw)
        value = (
            int(parsed)
            if parsed is not None
            and parsed == parsed.to_integral_value()
            and not re.search(r"[.,]", raw)
            else None
        )
        if value and value > 0:
            found.append(
                Match(
                    offset + match.start(group),
                    offset + match.end(group),
                    raw,
                    "CANTIDAD_ACCESORIO",
                    value,
                )
            )
    if len(found) == 2 and found[0].value != found[1].value:
        a, b = found
        return Match(a.start, b.end, text[a.start : b.end], "CANTIDAD_ACCESORIO", None)
    return found[0] if found else None
