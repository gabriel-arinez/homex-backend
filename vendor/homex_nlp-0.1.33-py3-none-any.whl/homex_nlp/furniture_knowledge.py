"""Finite furniture knowledge with literal evidence; never rewrites input text."""

from __future__ import annotations

import json
import re
from functools import lru_cache
from importlib.resources import files

from homex_nlp.contracts.evidence import Candidate, Warning
from homex_nlp.contracts.item import Color


@lru_cache(maxsize=1)
def lexicon():
    return json.loads(files("homex_nlp").joinpath("resources/furniture_lexicon.json").read_text())


def material_entry(raw):
    return next((x for x in lexicon()["materials"] if re.fullmatch(x["pattern"], raw, re.I)), None)


def recovery_material_context(text, start):
    if re.search(r"\b(?:de|en|con|tablero)\s+$", text[max(0, start - 45) : start], re.I):
        return True
    # A measured technical clause licenses this finite alias, not arbitrary prose.
    from homex_nlp.magnitudes import NUMBER, UNIT

    return bool(
        re.search(r"(?:^|[.;,])\s*$", text[:start])
        and re.match(
            rf"(?:me\s+lamina|melam[eé]nico)\s+de\s+{NUMBER}\s*{UNIT}",
            text[start:],
            re.I,
        )
    )


def commercial_family(name):
    # Keep the existing supported meeting-table family independent of capacity.
    if re.match(r"mesas?\s+de\s+reuni[oó]n\b", name, re.I):
        return "mesa de reunión"
    if re.match(r"cubos?\s+m[oó]vil(?:es)?\b", name, re.I):
        return "cubo móvil"
    if re.match(r"estaci(?:[oó]n|ones)\s+de\s+trabajo", name, re.I):
        return "estación de trabajo"
    first = name.split()[0].casefold()
    if first.endswith("es") and first[:-2].endswith("r"):
        first = first[:-2]
    elif first.endswith("s"):
        first = first[:-1]
    return {"gabetero": "gavetero", "gadetero": "gavetero", "estanteria": "estantería"}.get(
        first, first
    )


def noncommercial_furniture_context(text):
    """Reject explicit test/retrospective intent, not individual forbidden words."""
    return bool(
        re.search(
            r"\b(?:probando|probar|prueba\s+de)\b[^.;]{0,65}\b(?:micr[oó]fono|audio|voz)\b"
            r"|\b(?:ayer\s+hablamos|no\s+vamos\s+a\s+(?:comprar|cotizar))\b",
            text,
            re.I,
        )
    )


def enrich_knowledge(item, candidates, text, warnings):
    """Preserve finite aliases and bounded unsupported service specifications."""

    def add(start, end, label, value, decision="ACCEPTED", reason=None, component=None):
        existing = next(
            (c for c in candidates if c.start == start and c.end == end and c.label == label), None
        )
        if existing:
            return existing
        c = Candidate(
            candidate_id=f"c{len(candidates) + 1}",
            label=label,
            start=start,
            end=end,
            text=text[start:end],
            source="PARSER",
            normalized_value=value,
            decision=decision,
            reason=reason,
            component_ref=component,
        )
        candidates.append(c)
        if decision == "UNRESOLVED":
            item.unresolved.append(c.candidate_id)
        return c

    def recovery(c, value, rule):
        add(
            c.start,
            c.end,
            "RECUPERACION_LEXICA",
            value,
            "UNRESOLVED",
            f"Contextual lexical recovery ({rule}); confirm the proposed interpretation",
            c.component_ref,
        )
        warnings.append(
            Warning(
                code="UNKNOWN_TERM",
                path="/candidates",
                severity="REVIEW",
                message=f"Confirm contextual interpretation of {c.text!r} as {value!r}.",
            )
        )

    for c in list(candidates):
        if (
            c.label == "PRODUCTO"
            and c.decision == "ACCEPTED"
            and re.fullmatch(r"gadeteros?", c.text, re.I)
        ):
            value = "gaveteros" if c.text.casefold().endswith("s") else "gavetero"
            c.normalized_value = value
            item.name = value
            item.furniture_type_candidate = "gavetero"
            recovery(c, value, "counted_furniture_identity")
        if c.label == "MATERIAL" and c.decision == "ACCEPTED":
            entry = material_entry(c.text)
            if entry:
                c.normalized_value = entry.get("value", c.text)
                add(
                    c.start,
                    c.end,
                    "ROL_MATERIAL",
                    {"value": c.normalized_value, "role": entry["role"]},
                    "UNRESOLVED",
                    "Domain material classification, not an explicitly spoken substrate/coating relationship",
                    c.component_ref,
                )
                if entry.get("recovery"):
                    recovery(c, c.normalized_value, "technical_material_phrase")
        if (
            c.label == "COLOR"
            and c.decision == "ACCEPTED"
            and re.fullmatch(r"hueng[uü]e", c.text, re.I)
        ):
            c.normalized_value = "wengué"
            recovery(c, "wengué", "explicit_decorative_color")

    for match in re.finditer(r"\b(?:Novopan|nobopan|novo\s+pan)\b", text, re.I):
        before = text[max(0, match.start() - 65) : match.start()]
        if not re.search(r"\b(?:tablero|melam[ií]nic[oa]|melamina|MDP|MDF|marca)\b", before, re.I):
            continue
        c = add(match.start(), match.end(), "MARCA", "Novopan")
        if not re.fullmatch("Novopan", match.group(), re.I):
            recovery(c, "Novopan", "board_brand_context")

    for choice in re.finditer(r"\bcolor(?:es)?\s+(?:a\s+)?elecci[oó]n\b", text, re.I):
        add(
            choice.start(),
            choice.end(),
            "SELECCION_COLOR",
            None,
            "UNRESOLVED",
            "Color selection remains pending; no color was pronounced",
        )
    for clause in re.finditer(
        r"\bcolor\s+(?P<value>[^.;\n]+?)(?=[.;\n]|\b(?:garant[ií]a|precio|procedencia)\b|$)",
        text,
        re.I,
    ):
        if re.fullmatch(r"(?:a\s+)?elecci[oó]n\s*", clause["value"], re.I):
            continue
        known = [
            c
            for c in candidates
            if c.label == "COLOR"
            and clause.start("value") <= c.start
            and c.end <= clause.end("value")
            and c.decision == "ACCEPTED"
        ]
        rest = text[clause.start("value") : clause.end("value")]
        for c in sorted(known, key=lambda x: x.start, reverse=True):
            a, b = c.start - clause.start("value"), c.end - clause.start("value")
            rest = rest[:a] + " " + rest[b:]
        if re.sub(r"\b(?:con|y)\b|[\s,]+", "", rest, flags=re.I):
            for c in known:
                c.decision = "UNRESOLVED"
                c.reason = "Color combination contains an unknown term; do not silently select only a known member"
                if c.candidate_id not in item.unresolved:
                    item.unresolved.append(c.candidate_id)
            item.primary_color = item.secondary_color = None
            add(
                clause.start("value"),
                clause.end("value"),
                "COLOR_NO_RESUELTO",
                clause["value"].strip(),
                "UNRESOLVED",
                "Confirm the complete literal color description",
            )

    colors = [
        c
        for c in candidates
        if c.label == "COLOR" and c.decision == "ACCEPTED" and c.component_ref is None
    ]
    if len(colors) == 1 and item.primary_color is None:
        c = colors[0]
        main = next(
            (x for x in candidates if x.label == "PRODUCTO" and x.decision == "ACCEPTED"), None
        )
        explicit = re.search(r"\bcolor\s+$", text[max(0, c.start - 25) : c.start], re.I)
        adjacent = main and re.fullmatch(r"\s+", text[main.end : c.start])
        ambiguous = re.search(
            r"\b(?:o|mejor|corrijo|perd[oó]n|sino)\b", text[main.end :] if main else text, re.I
        )
        if (explicit or adjacent) and not ambiguous:
            value = c.normalized_value or c.text.casefold()
            value = re.sub(r"^blanc[oa]s?$", "blanco", str(value))
            value = re.sub(r"^negr[oa]s?$", "negro", value)
            c.normalized_value = value
            item.primary_color = Color(value=value, evidence_ids=[c.candidate_id])

    for accessory in item.accessories:
        if re.match(r"conjalador(?:es)?\b", accessory.name, re.I):
            c = next(x for x in candidates if x.candidate_id in accessory.evidence_ids)
            accessory.name = re.sub(r"^con", "", accessory.name, flags=re.I)
            recovery(c, accessory.name, "joined_accessory_connector")

    # These are bounded clauses, not an indiscriminate transcript copy.
    pattern = re.compile(
        r"\b(?:garant[ií]a|procedencia|origen|incluye\s+(?:instalaci[oó]n|entrega|traslado)|"
        r"(?:instalaci[oó]n|entrega|traslado)\s+(?:incluid[oa]|a\s+)|"
        r"resistente\s+a|condiciones\s+de\s+fabricaci[oó]n|"
        r"regatones?\s+engomados?|acabado\s+con\s+pintura|"
        r"espacio(?:s)?\s+(?:central|abierto)|decoraci[oó]n\s+frontal|"
        r"caracter[ií]sticas?\s+seg[uú]n\s+dise[nñ]o|"
        r"(?:dos|tres|cuatro|\d+)\s+por\s+lado)\b"
        r"[^.;\n]*?(?=[.;\n]|\b(?:precio|color|garant[ií]a|procedencia)\b|$)",
        re.I,
    )
    retained = []
    for m in pattern.finditer(text):
        segment = m.group().strip()
        if not segment:
            continue
        add(
            m.start(),
            m.start() + len(segment),
            "ESPECIFICACION",
            segment,
            "UNRESOLVED",
            "Technical/service specification retained for human review",
        )
        retained.append(segment)
    # A literal physical measure with degraded context is not automatically a
    # thickness. Preserve its complete span for review instead of losing it or
    # inventing the missing board/material (including unsupported ASR phrases).
    from homex_nlp.magnitudes import NUMBER, UNIT, length
    from homex_nlp.rules import _fragmento_numerico_truncado, is_explicitly_negated

    def retain_unknown(start, end):
        if is_explicitly_negated(text, start):
            return
        segment = text[start:end].strip()
        if not segment:
            return
        add(
            start,
            start + len(segment),
            "ESPECIFICACION",
            segment,
            "UNRESOLVED",
            "Unmapped literal technical description; confirm meaning without a catalog reference",
        )
        retained.append(segment)

    # These phrases preserve spoken evidence, not a new canonical material or finish.
    for m in re.finditer(
        r"\benchapad[oa]s?\b|\bacabado\s+(?:(?:de|con)\s+)?poliuretano\b", text, re.I
    ):
        retain_unknown(m.start(), m.end())

    # Explicit brand cues are required. Stop before another field or owner clause.
    stops = (
        r"color(?:es)?|modelo|precio|de|con|y|sin|no|marca|material(?:es)?|acabado|"
        r"en|garant[ií]a|ancho|alto|largo|profundidad|para|capacidad"
    )
    # Nominal connectors and numeric tokens can be part of an unknown brand.
    # Retain the complete literal clause, cutting only at another explicit field,
    # measured quantity, commercial amount or introduced component/order.
    brand_boundary = re.compile(
        r"[,;\n]|[.](?!\d)|\b(?:color(?:es)?|modelo|precio|marca|material(?:es)?|"
        r"acabado|garant[ií]a|ancho|alto|largo|profundidad|capacidad)\b"
        rf"|\b(?:(?:de|con|en)\s+)?{NUMBER}\s*{UNIT}\b"
        rf"|\b(?:por|a)\s+{NUMBER}\s*(?:bolivianos?|bol[ií]vares?|Bs|USD|d[oó]lares?)\b"
        r"|\b(?:con|incluye|incorpora)\s+",
        re.I,
    )
    for cue in re.finditer(r"\bmarca\s+", text, re.I):
        tail = text[cue.end() :]
        boundary = brand_boundary.search(tail)
        end = cue.end() + boundary.start() if boundary else len(text)
        # A counted new entity after 'y' is an owner boundary, not a brand token.
        for c in candidates:
            if c.label not in {"PRODUCTO", "COMPONENTE"} or not cue.end() <= c.start < end:
                continue
            connector = re.search(rf"\by\s+(?:{NUMBER}\s+)?$", text[cue.end() : c.start], re.I)
            if connector:
                end = cue.end() + connector.start()
        end = len(text[:end].rstrip())
        if end <= cue.end() or not re.search(r"[a-záéíóúñ]", text[cue.end() : end], re.I):
            continue
        if any(c.label == "MARCA" and c.start < end and cue.start() < c.end for c in candidates):
            continue
        retain_unknown(cue.start(), end)

    # Only a direct main-noun complement or an explicit material cue licenses
    # this description. Its classification stays unknown, never MATERIAL.
    material_word = rf"(?!(?:{stops}|personas?|puestos?|ruedas?|caj[oó]n(?:es)?)\b)[a-záéíóúñ]+"
    material_tail = rf"{material_word}(?:\s+{material_word}){{0,2}}\b"
    material_matches = list(
        re.finditer(rf"\bmaterial(?:es)?\s+(?:de\s+)?{material_tail}", text, re.I)
    )
    main = next((c for c in candidates if c.label == "PRODUCTO" and c.decision == "ACCEPTED"), None)
    if main:
        m = re.compile(rf"\s+(?P<detail>de\s+{material_tail})", re.I).match(text, main.end)
        if m:
            material_matches.append(m)
    for m in material_matches:
        start = m.start("detail") if "detail" in m.re.groupindex else m.start()
        end = m.end()
        segment = text[start:end]
        value = re.sub(r"^(?:material(?:es)?\s+)?(?:de\s+)?", "", segment, flags=re.I)
        if (
            re.match(rf"(?:{NUMBER})\b", value, re.I)
            or re.search(r"\d", text[end : end + 1])
            or any(
                c.label
                in {
                    "MATERIAL",
                    "COLOR",
                    "ACCESORIO",
                    "ANCHO",
                    "ALTO",
                    "LARGO",
                    "PROFUNDIDAD",
                    "ESPESOR",
                }
                and c.start < end
                and start < c.end
                for c in candidates
            )
        ):
            continue
        retain_unknown(start, end)

    for m in re.finditer(rf"(?<![\w.,]){NUMBER}\s*{UNIT}", text, re.I):
        value, unit = length(m.group())
        if (
            value is None
            or _fragmento_numerico_truncado(text, m.start())
            or is_explicitly_negated(text, m.start())
            or any(
                c.label
                in {"ANCHO", "ALTO", "LARGO", "PROFUNDIDAD", "DIAMETRO", "ESPESOR", "DIMENSION"}
                and c.start < m.end()
                and m.start() < c.end
                for c in candidates
            )
        ):
            continue
        add(
            m.start(),
            m.end(),
            "MEDIDA_NO_CLASIFICADA",
            {"value": str(value), "unit": unit},
            "UNRESOLVED",
            "Literal measurement retained; axis, physical role and owner require confirmation",
        )
        retained.append(m.group())
    if retained:
        item.observations = "; ".join(dict.fromkeys(filter(None, [item.observations, *retained])))
